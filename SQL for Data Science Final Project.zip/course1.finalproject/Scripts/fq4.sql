-- There's a meeting with the Honey Council next week. 

-- Find the average honey production for 2022 so you're prepared. 

SELECT AVG(hp.Value)
FROM honey_production hp 
WHERE Year = 2022 
;

























