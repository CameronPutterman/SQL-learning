PRAGMA table_info(coffee_production);
PRAGMA table_info(coffee_production_test);