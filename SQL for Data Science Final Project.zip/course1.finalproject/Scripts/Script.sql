CREATE table parrots (
name VARCHAR(25),
species VARCHAR (60),
age int 
);
