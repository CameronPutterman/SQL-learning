SELECT State
,State_ANSI
FROM state_lookup sl 
WHERE State is 'IOWA'
;