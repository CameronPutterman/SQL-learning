-- Can you find out the total milk production for 2023? Your manager wants this information for the yearly report.

-- What is the total milk production for 2023?

SELECT SUM(Value)
FROM milk_production mp 
WHERE Year = 2023
;
















