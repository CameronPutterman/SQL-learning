SELECT SUM(Value)
FROM milk_production mp 
WHERE Year = 2023
;