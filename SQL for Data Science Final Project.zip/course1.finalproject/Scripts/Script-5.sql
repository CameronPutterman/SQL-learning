CREATE TABLE state_lookup
(State TEXT
,State_ANSI INTEGER
);