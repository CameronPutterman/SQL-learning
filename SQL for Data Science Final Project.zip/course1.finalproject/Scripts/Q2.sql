SELECT SUM(cp.Value)
FROM coffee_production cp 
WHERE Year = 2015
;