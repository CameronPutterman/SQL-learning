SELECT AVG(Value)
FROM honey_production hp 
WHERE Year = 2022
;

SELECT SUM(Value)
FROM honey_production hp 
WHERE Year = 2022
;