CREATE TABLE honey_production
(Year INTEGER
,Geo_Level TEXT
,State_ANSI INTEGER
,Commodity_ID INTEGER
,Value INTEGER
);
CREATE TABLE yogurt_production
(Year INTEGER
,Geo_Level TEXT
,State_ANSI INTEGER
,Commodity_ID INTEGER
,Value INTEGER
);


