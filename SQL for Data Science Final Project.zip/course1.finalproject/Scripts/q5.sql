SELECT Value
FROM yogurt_production yp 
WHERE Year = 2022
ORDER BY Value DESC ;