CREATE TABLE milk_production 
(Year INTEGER,
Period TEXT,
Geo_Level TEXT,
State_ANSI INTEGER,
Commodity_ID INTEGER,
Domain TEXT,
Value INTEGER)
;